package com.example.part2poe.ui.main_project

import androidx.lifecycle.ViewModel

class MainProjectViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}