package com.example.part2poe.ui.add_project

import androidx.lifecycle.ViewModel

class AddProjectViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}